"qqchi" <-
function(y, ...)
  {
    UseMethod("qqchi")
  }

