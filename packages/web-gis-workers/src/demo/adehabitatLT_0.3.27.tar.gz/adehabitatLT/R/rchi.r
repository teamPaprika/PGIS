"rchi" <-
function(n, df=2)
  {
    return(sqrt(rchisq(n, df)))
  }

